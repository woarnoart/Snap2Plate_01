import React from 'react';
import { TouchableOpacity, Text, Image, StyleSheet, View } from 'react-native';

export default function RecipeCard({ title, image, onPress }) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Image source={{ uri: image }} style={styles.image} />
      <View style={styles.textContainer}>
        <Text style={styles.title}>{title}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { margin: 10, borderRadius: 10, overflow: 'hidden', backgroundColor: '#fff', elevation: 3 },
  image: { width: '100%', height: 150 },
  textContainer: { padding: 10 },
  title: { fontSize: 18, fontWeight: 'bold' },
});