import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator } from 'react-native';
import RecipeCard from '../components/RecipeCard';
import { fetchRecipesFromImage } from '../services/api';

export default function ResultScreen({ route, navigation }) {
  const { imageUri } = route.params;
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecipesFromImage(imageUri).then((results) => {
      setRecipes(results);
      setLoading(false);
    });
  }, []);

  if (loading) return <ActivityIndicator size="large" style={{ marginTop: 50 }} />;

  return (
    <FlatList
      data={recipes}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => (
        <RecipeCard
          title={item.title}
          image={item.image}
          onPress={() => navigation.navigate('Recipe', { recipe: item })}
        />
      )}
    />
  );
}