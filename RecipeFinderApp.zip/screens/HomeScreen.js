import React, { useState } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import ImagePickerButton from '../components/ImagePickerButton';

export default function HomeScreen({ navigation }) {
  const [selectedImage, setSelectedImage] = useState(null);

  const handleImagePicked = (imageUri) => {
    setSelectedImage(imageUri);
    navigation.navigate('Results', { imageUri });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Find Recipes by Photo</Text>
      <ImagePickerButton onImagePicked={handleImagePicked} />
      {selectedImage && <Image source={{ uri: selectedImage }} style={styles.preview} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  preview: { width: 200, height: 200, marginTop: 20, borderRadius: 10 },
});